﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class HomeController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            int? logueadoId = HttpContext.Session.GetInt32("LogueadoId");
            string logueadoNombre = HttpContext.Session.GetString("LogueadoNombre");
            if (logueadoId != null)
            {
                ViewBag.msg = $"{logueadoNombre} has ingresado correctamente ";
            }

            return View();
        }

        public IActionResult Login()
        {
            int? logueadoId = HttpContext.Session.GetInt32("LogueadoId");

            if (logueadoId != null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View();
            }
        }





        [HttpPost]
        public IActionResult Login(string email, string pass)
        {
            Usuario buscada = s.Login(email, pass);
            if (buscada != null)
            {
                HttpContext.Session.SetInt32("LogueadoId", buscada.Id);
                HttpContext.Session.SetString("LogueadoRol", buscada.GetTipo());
                HttpContext.Session.SetString("LogueadoNombre", buscada.Nombre);


                return RedirectToAction("Index");

            }
            else
            {
                ViewBag.msg = "Error";

                return View();
            }


        }


        public IActionResult Logout()
        {

            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
