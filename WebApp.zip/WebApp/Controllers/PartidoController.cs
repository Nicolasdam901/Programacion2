﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace WebApp.Controllers
{
    public class PartidoController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult Index()
        {
            int? logueadoId = HttpContext.Session.GetInt32("LogueadoId");
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoId != null)
            {
                List<Partido> listaPartido = s.GetPartidos();
                ViewBag.msg = logueadoRol;
                return View(listaPartido);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }

        public IActionResult Edit(int id)
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "OPE")
            {
                Partido buscado = s.GetPartidoId(id);
                if (buscado != null)
                { 
                
                    s.FinalizarP(buscado);
                
                    return View(buscado);
                
                }
                else
                    {
                        return RedirectToAction("Index", "Home");

                    }


            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Create(int id)
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");
            if (logueadoRol == "PER")
            {

                Partido buscado = s.GetPartidoId(id);
                if (buscado != null)
                {

                    if (buscado.Finalizado == true)
                    {

                        return View(buscado);
                    }
                    else
                    {
                        return RedirectToAction("Index", "Home");

                    }
                }
                else
                {
                    return RedirectToAction("Index", "Home");

                }
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }

        [HttpPost]
        public IActionResult Create(string TituloReseña, string Contenido, int Id)
        {

            int? idLogueado = HttpContext.Session.GetInt32("LogueadoId");
            Partido buscado = s.GetPartidoId(Id);

            try
            {
                s.AltaReseñaPeriodista(idLogueado, TituloReseña, Contenido, buscado);
                ViewBag.msg = "Se dió de alta y se asoció correctamente";
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }

            return View(buscado);
        }

        public IActionResult Filtro()
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "OPE")
            {
                List<Partido> listaPartido = s.GetPartidos();
                return View(listaPartido);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }
        [HttpPost]
        public IActionResult Filtro(string filtroF1, string filtroF2)
        {
            try
            {
                List<Partido> listaPartido = s.GetPartidosFechas(filtroF1, filtroF2);
                if(listaPartido.Count==0)
                {
                    ViewBag.msg = "No hay datos";
                }
                return View(listaPartido);
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }
            return View();

        }

        public IActionResult FiltroP()
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "OPE")
            {
                return View();

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }

        [HttpPost]
        public IActionResult FiltroP(string filtro)
        {
            try
            {
                Periodista per = s.GetPeriodistaEmail(filtro);
                if (per != null)
                {
                    List<Reseña> listaReseña = s.GetReseñaPeriodistas(per);
                    List<Partido> listaPartido = s.GetPartidosRojasReseñado(listaReseña);
                    ViewBag.msg = true;
                    return View(listaPartido);
                }


            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }
            return View();



        }
    }
}
