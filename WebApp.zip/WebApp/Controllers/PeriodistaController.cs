﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.Controllers
{
    public class PeriodistaController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult Index()
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "OPE")
            {
                List<Periodista> listaPeriodista = s.GetPeriodistas();
                return View(listaPeriodista);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Create()
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");
            if (logueadoRol == null)
            {
                return View();

            }
            else
            {
                return RedirectToAction("Index", "Home");

            }
        }

        [HttpPost]
        public IActionResult Create(Periodista periodista)
        {

            try
            {
                s.AltaPeriodista(periodista);
                ViewBag.msg = "Alta correcta";
            }
            catch (Exception e)
            {
                ViewBag.msg = e.Message;
            }


            return View();
        }




    }
}
