﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace WebApp.Controllers
{
    public class ReseñaController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult Index(int id)
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "OPE")
            {
                Periodista buscado = s.GetPeriodistaId(id);
                if (buscado == null)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    List<Reseña> listaReseña = s.GetReseñaPeriodistasOPE(buscado);
                    if (listaReseña.Count == 0)
                    {
                        ViewBag.msg = "No hay reseñas";
                        return View(listaReseña);
                    }
                    else
                    {
                        ViewBag.msg = "logueadoRol";

                        return View(listaReseña);

                    }

                }

            }
            else if (logueadoRol == "PER")
            {
                int? logueadoId = HttpContext.Session.GetInt32("LogueadoId");
                Periodista perfil = s.GetPeriodistaId(logueadoId);

                List<Reseña> listaReseña = s.GetReseñaPeriodistas(perfil);
                if (listaReseña.Count == 0)
                {
                    ViewBag.msg = "No hay reseñas";
                    return View(listaReseña);
                }
                else
                {
                    ViewBag.msg = logueadoRol;

                    return View(listaReseña);

                }

            }
            else
            {
                return RedirectToAction("Index", "Home");

            }
        }

    }
}
