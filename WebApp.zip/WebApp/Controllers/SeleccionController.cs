﻿using Dominio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.Controllers
{
    public class SeleccionController : Controller
    {
        Sistema s = Sistema.GetInstancia();

        public IActionResult Index()
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "PER")
            {
                return RedirectToAction("Index", "Home");

            }
            else
            {
                List<Seleccion> listaSelecciones = s.GetSelecciones();
                return View(listaSelecciones);
            }
        }

        public IActionResult MasGoles()
        {
            string logueadoRol = HttpContext.Session.GetString("LogueadoRol");

            if (logueadoRol == "OPE")
            {
                try
                {

                    List<Seleccion> listaSelecciones = s.GetSeleccionesMasGoles();
                    return View(listaSelecciones);

                }
                catch (Exception e)
                {
                    ViewBag.msg = e.Message;
                }
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");

            }
        }
    }
}
